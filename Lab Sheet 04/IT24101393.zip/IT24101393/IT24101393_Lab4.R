setwd("C:\\Users\\it24100661\\Desktop\\Lab 4")
getwd()

#1
data <- read.table("DATA 4.txt", header=TRUE, sep=" ")

fix(data)
